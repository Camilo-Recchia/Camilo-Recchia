/*
 *Descripción: Numero del 100 al 1 con un do while 
 *Autor: Camilo Villarroel Recchia
 *Fecha: 14/10/2025
 */
package ejercicio3;

public class Ejercicio3 {

	public static void main(String[] args) {

		int numero = 100;

		do {
			System.out.print(numero + " ");
			numero--;
		} while (numero >= 1);
	}

}
