/*
 *Descripción: Numero del 1 al 100 con un while 
 *Autor: Camilo Villarroel Recchia
 *Fecha: 14/10/2025
 */
package ejercicio1;

public class Ejercicio1 {

	public static void main(String[] args) {

		int numero = 1;

		while (numero <= 100) {

			System.out.print(numero + " ");
			numero++;

		}

	}

}
