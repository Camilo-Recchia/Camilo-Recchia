/*
 *Descripción: Numero del 1 al 100 con un do while 
 *Autor: Camilo Villarroel Recchia
 *Fecha: 14/10/2025
 */
package ejercicio2;

public class Ejercicio2 {

	public static void main(String[] args) {

		int numero = 1;

		do {
			System.out.print(numero + " ");
			numero++;
		} while (numero <= 100);

	}

}
